from django.apps import AppConfig


class TheKillersAppConfig(AppConfig):
    name = 'the_killers_app'
