from django import forms
from .models import Shows


class ShowsForm(forms.ModelForm):

    class Meta:
        model = Shows
        fields = ('data', 'local', 'link_reserva', 'link_compra')


class RemoverShowsForm(forms.ModelForm):

    class Meta:
        model = Shows
        fields = ('id',)

    id = forms.CharField(widget=forms.HiddenInput(), required=True)