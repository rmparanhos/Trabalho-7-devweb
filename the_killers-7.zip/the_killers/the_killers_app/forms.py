from django import forms
from .models import Shows, Carrinho


class ShowsForm(forms.ModelForm):

    class Meta:
        model = Shows
        fields = ('data', 'local', 'link_reserva', 'link_compra')


class RemoverShowsForm(forms.ModelForm):

    class Meta:
        model = Shows
        fields = ('id',)

    id = forms.CharField(widget=forms.HiddenInput(), required=True)


class AtualizaCarrinhoForm(forms.ModelForm):

    class Meta:
        model = Carrinho
        # O campo fields abaixo impede que seja atualizado um campo não especificado na lista abaixo. Deve ser especificado o
        # campo fields ou o campo exclude.
        fields = ('id', 'qtd')

    id = forms.CharField(widget=forms.HiddenInput(), required=True)

    estoque = forms.IntegerField(
        min_value=1,
        max_value=1000,
        error_messages={'required': 'Campo obrigatório.', },
        widget=forms.TextInput(attrs={'class': 'form-control form-control-sm qtd',
                                      'maxlength': '20',
                                      'onkeypress': 'return event.charCode >= 48 && event.charCode <= 57'}),
        required=True)

class RemoveCarrinhoForm(forms.Form):
    class Meta:
        fields = ('id')

    id = forms.CharField(widget=forms.HiddenInput())


class CarrinhoForm(forms.ModelForm):

    class Meta:
        model = Carrinho
        # O campo fields abaixo impede que seja atualizado um campo não especificado na lista abaixo. Deve ser especificado o
        # campo fields ou o campo exclude.
        fields = ('qtd',)

    qtd = forms.IntegerField(
        min_value=0,
        max_value=1000,
        error_messages={'required': 'Campo obrigatório.', },
        widget=forms.TextInput(attrs={'class': 'form-control form-control-sm',
                                      'maxlength': '20',
                                      'onkeypress': 'return event.charCode >= 48 && event.charCode <= 57'}),
        required=True)

