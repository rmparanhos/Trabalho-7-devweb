"""the_killers URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('home', views.home, name='home'),
    path('music', views.music, name='music'),
    path('photos', views.photos, name='photos'),
    path('showtime', views.showtime, name='showtime'),
    path('videos', views.videos, name='videos'),
    path('cadastro_show', views.cadastro_show, name='cadastro_show'),
    path('editar_show/<int:id>/', views.editar_show, name='editar_show'),
    path('remover_show/<int:id>', views.remover_show, name='remover_show'),
    path('adicionar_show_carrinho/<int:id>', views.adicionar_show_carrinho, name='adicionar_show_carrinho'),
    path('carrinho',views.carrinho,name='carrinho')
]
