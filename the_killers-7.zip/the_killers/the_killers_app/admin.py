from django.contrib import admin
from .models import Shows, Carrinho


class ShowsAdmin(admin.ModelAdmin):
    list_display = ['data', 'local','link_reserva','link_compra']
    search_fields = ['data', 'local','link_reserva','link_compra']

admin.site.register(Shows, ShowsAdmin)  # Registre a classe Categoria com os produtos
                                                # definidos em CategoriaAdmin

class CarrinhoAdmin(admin.ModelAdmin):
    list_display = ['user', 'show', 'qtd']
    search_fields = ['user', 'show', 'qtd']

admin.site.register(Carrinho, CarrinhoAdmin)  # Registre a classe Categoria com os produtos
                                                # definidos em CategoriaAdmin