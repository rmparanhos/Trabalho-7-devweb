from django.contrib.auth.models import User
from django.shortcuts import render, redirect, get_object_or_404
# Create your views here.
import autenticacao
from the_killers_app.models import Images, Shows, Carrinho
from .forms import ShowsForm, RemoverShowsForm, AtualizaCarrinhoForm, RemoveCarrinhoForm
from django.contrib import messages

def home(request):
    caminhos = {}
    for item in Images.objects.filter(nome__contains='home'):
        caminhos[item.nome] = "the_killers_app/images/" + item.caminho
    return render(request,'home.html',caminhos)


def music(request):
    caminhos = {}
    for item in Images.objects.filter(nome__contains='music'):
        caminhos[item.nome] = "the_killers_app/images/" + item.caminho
    return render(request, 'music.html',caminhos)


def photos(request):
    caminhos={}
    for item in Images.objects.filter(nome__contains='photos'):
        caminhos[item.nome] = "the_killers_app/images/"+item.caminho
    return render(request, 'photos.html',caminhos)


def showtime(request):
    caminhos = {}
    for item in Images.objects.filter(nome__contains='showtime'):
        caminhos[item.nome] = "the_killers_app/images/" + item.caminho
    shows = []
    for item in Shows.objects.filter():
        shows.append(item)
    caminhos['shows'] = shows
    return render(request, 'showtime.html',caminhos)


def videos(request):
    caminhos = {}
    for item in Images.objects.filter(nome__contains='videos'):
        caminhos[item.nome] = "the_killers_app/images/"+item.caminho
    return render(request, 'videos.html', caminhos)


def cadastro_show(request):
    if request.method == "POST":
        form = ShowsForm(request.POST)
        if form.is_valid():
            show = form.save(commit=False)
            show.save()
            return redirect('showtime')
    else:
        form = ShowsForm()
    return render(request, 'cadastro_show.html', {'form': form})

def editar_show(request,id):
    show = get_object_or_404(Shows, pk=id)
    if request.method == "POST":
        form = ShowsForm(request.POST,instance=show)
        print(form)
        if form.is_valid():
            show = form.save(commit=False)
            show.save()
            return redirect('showtime')
    else:
        form = ShowsForm()
    return render(request, 'editar_show.html', {'form': form,'show':show})


def remover_show(request, id):
    show = get_object_or_404(Shows, pk=id)
    if request.method == "GET":
        show.delete()
        return redirect('showtime')
    else:
        form = ShowsForm()
    return render(request, 'editar_show.html', {'form': form, 'show': show})

def adicionar_show_carrinho(request,id):
    show = get_object_or_404(Shows, pk=id)
    user = User.objects.get(username=request.user.username)
    if Carrinho.objects.filter(user=user,show=show).__len__() == 0:
        show_carrinho = Carrinho.objects.create(user=user,show=show,qtd=1)
        messages.info(request, "Ingresso para o Show no " + show.local + " adicionado ao carrinho")
    elif Carrinho.objects.filter(user=user,show=show).__len__() == 1:
        show_carrinho = Carrinho.objects.get(user=user,show=show)
        messages.info(request, "Numero de ingressos para o Show no " + show.local + " no carrinho foi aumentado de " + show_carrinho.getQtd() + " para " +show_carrinho.getQtdMaisUm())
        show_carrinho.qtd += 1
        show_carrinho.save()
    return redirect('showtime')

def carrinho(request):
    carrinho_dict = {}
    user = User.objects.get(username=request.user.username)
    itens = []
    for item in Carrinho.objects.filter(user=user):
        itens.append(item)
    carrinho_dict['itens'] = itens
    return render(request, 'carrinho.html', carrinho_dict)

def atualiza_show_carrinho(request):
    form = AtualizaCarrinhoForm(request.POST)
    print(form)
    if form.is_valid():
        print("oi2")
        carrinho = get_object_or_404(Carrinho, pk=form.cleaned_data['id'])
        carrinho.qtd = form.cleaned_data['qtd']
        carrinho.save()

        #resultado = Carrinho.objects.filter(disponivel=True).aggregate(
        #    valor_do_estoque=Sum(F('estoque') * F('preco'), output_field=FloatField()))
        #return render(request, 'produto/valor_do_estoque.html',
        #              {'valor_do_estoque': "{0:.2f}".format(resultado['valor_do_estoque'])})
        # return HttpResponse("{0:.2f}".format(resultado['valor_do_estoque']).replace('.',','))
        return redirect('carrinho')
    else:
        print(form.errors)
        raise ValueError('Ocorreu um erro inesperado ao tentar alterar um produto!')


def remover_show_carrinho(request):
        print('Entrou em remove_produto')
        form = RemoveCarrinhoForm(request.POST)
        if form.is_valid():
            carrinho = get_object_or_404(Carrinho, pk=form.cleaned_data['id'])
            print(carrinho)
            carrinho.delete()

            # A linha de código abaixo irá retornar none para resultado['valor_do_estoque'] caso a soma do produto
            # (estoque * preco) seja igual a zero. Por essa razão acrescentei o if ... else ... abaixo.
            #resultado = Produto.objects.filter(disponivel=True).aggregate(
            #    valor_do_estoque=Sum(F('estoque') * F('preco'), output_field=FloatField()))

            #if resultado['valor_do_estoque']:
            #    return render(request, 'produto/valor_do_estoque.html',
            #                  {'valor_do_estoque': '{0:.2f}'.format(resultado['valor_do_estoque'])})
            #else:
            #   return render(request, 'produto/valor_do_estoque.html', {'valor_do_estoque': '0,00'})
            # return HttpResponse("{0:.2f}".format(resultado['valor_do_estoque']).replace('.',','))
            return redirect('carrinho')
        else:
            raise ValueError('Ocorreu um erro inesperado ao tentar remover um produto!')